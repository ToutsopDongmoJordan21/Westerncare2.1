export class Client {
    id?: string;
    name?: string;
    username?: string;
    profession?:string;
    phone?: string
    email?: string;
    createBy?: string;
    dates?: Date;
    nationality?:string;
    sexe?:string;
    imageUrl?: string;
    ville?: string;
    pays?:string;
    continent?:string;
    categories?:string;
    service?:string;
    statut?: string;
    addedDate?: Date;
    typeClient?:string;
    langue?:string;
    typeService?:string;

}