export class User {
    id?: string;
    username?: string;
    phone?: string;
    postes?: string;
    password?: string;
    email?: string;
    profilePicture?: string;
    createBy?: string;
    date?: Date;
    imageUrl?: string;


}