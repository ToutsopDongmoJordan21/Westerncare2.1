import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-log-out-mg',
  templateUrl: './log-out-mg.component.html',
  styleUrls: ['./log-out-mg.component.css']
})
export class LogOutMgComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
